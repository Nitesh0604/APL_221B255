class Arjun extends Pandav {
    // Inherits all methods from Pandav
}
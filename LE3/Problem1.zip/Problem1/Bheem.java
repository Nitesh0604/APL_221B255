class Bheem extends Pandav {
    void kind() {
        System.out.println("Bheem is less kind.");
    }
}
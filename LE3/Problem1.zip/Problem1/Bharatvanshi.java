abstract class Bharatvanshi {
    abstract void fight();
    abstract void obey();
    abstract void kind();
}
class Pandav extends Bharatvanshi {
    void fight() {
        System.out.println("Pandav fights bravely.");
    }

    void obey() {
        System.out.println("Pandav obeys diligently.");
    }

    void kind() {
        System.out.println("Pandav shows kindness.");
    }
}
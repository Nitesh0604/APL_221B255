class Duryodhan extends Kaurav {
    // Inherits all methods from Kaurav
}
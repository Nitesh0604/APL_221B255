class Kaurav extends Bharatvanshi {
    void fight() {
        System.out.println("Kaurav fights fiercely.");
    }

    void obey() {
        System.out.println("Kaurav disobeys often.");
    }

    void kind() {
        System.out.println("Kaurav is cruel.");
    }
}
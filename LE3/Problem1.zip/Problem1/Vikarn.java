class Vikarn extends Kaurav {
    void obey() {
        System.out.println("Vikarn obeys diligently.");
    }

    void kind() {
        System.out.println("Vikarn shows kindness.");
    }
}
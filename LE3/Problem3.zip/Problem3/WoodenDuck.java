public class WoodenDuck implements Swimmable {
    public void swim() {
        System.out.println("WoodenDuck swims.");
    }
}

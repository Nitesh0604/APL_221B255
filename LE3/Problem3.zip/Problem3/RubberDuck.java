public class RubberDuck implements Swimmable, Quackable {
    public void swim() {
        System.out.println("RubberDuck swims.");
    }

    public void quack() {
        System.out.println("RubberDuck squeaks.");
    }
}

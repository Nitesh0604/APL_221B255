interface Testable {
    void display();  // Method declaration
}